/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the COPYING file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "h5test.h"

#define H5F_FRIEND /*suppress error about including H5Fpkg	  */
#include "H5Fpkg.h"
#include "H5CXprivate.h" /* API Contexts                         */
#include "H5Iprivate.h"
#include "H5Pprivate.h" /* Property lists                       */

static const char *FILENAME[] = {"efc0", "efc1", "efc2", "efc3", "efc4", "efc5", NULL};

/* Windows doesn't have PATH_MAX */
#ifndef PATH_MAX
#define PATH_MAX 4096
#endif /* !PATH_MAX */

/* Global patched filename buffer */
#define N_FILENAMES 6
static char *filename[N_FILENAMES];

/* Global property lists - just copies of the defaults (necessary to use
 * internal functions */
hid_t fcpl_id = H5I_INVALID_HID;
hid_t fapl_id = H5I_INVALID_HID;

/*-------------------------------------------------------------------------
 * Function:    test_single
 *
 * Purpose:     Tests manipulations on a single external file cache.
 *
 * Return:      Success: 0
 *              Failure: Number of errors
 *
 *-------------------------------------------------------------------------
 */
static unsigned
test_single(void)
{
    H5F_t *f0    = NULL; /* Parent file containing EFC */
    H5F_t *f1    = NULL; /* Child file */
    H5F_t *f2    = NULL; /* Child file */
    H5F_t *f3    = NULL; /* Child file */
    H5F_t *f4    = NULL; /* Child file */
    H5F_t *ftmp1 = NULL; /* Temp file */
    H5F_t *ftmp2 = NULL; /* Temp file */
    H5F_t *ftmp3 = NULL; /* Temp file */
    H5F_t *ftmp4 = NULL; /* Temp file */

    TESTING("single EFC");

    /* Set EFC size to 3. Do this instead of H5F__efc_create() so we can pass
     * a file pointer to H5F__efc_open containing the EFC.
     */
    if (H5Pset_elink_file_cache_size(fapl_id, 3) < 0)
        TEST_ERROR;

    /* Open parent file */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;

    /* Disable EFC for child files */
    if (H5Pset_elink_file_cache_size(fapl_id, 0) < 0)
        TEST_ERROR;

    /* Test 1: Open file 1 through EFC, close, then open normally, verify ref
     * count = 2, release EFC, verify ref count = 1. Verifies a file can be
     * held open by the EFC.
     */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 2: Verify that subsequent efc_open requests return the cached top
     * level file pointer.  Open file 1 through EFC, close, open again, verify
     * file pointers are the same. */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    ftmp1 = f1;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1 != ftmp1)
        TEST_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;

    /* Test 3: Verify LRU functionality.  Add four files to the EFC and verify
     * that the one added first is evicted.  Then reopen files in a different
     * order.  Open each file normally after closing through EFC the first time
     * to track ref counts. */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp3) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &ftmp4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp4) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 4: Verify that files kept open through the EFC are not evicted by
     * H5F__efc_release(). */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 5: Verify that files kept open through the EFC are not evicted by
     * filling up the cache.  Open 4 files while holding the first open.  Verify
     * that the second file is evicted.  Close the first file, reopen the
     * second, and verify that the first file is evicted. */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared != f1->shared)
        TEST_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f4) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 6: Verify that having a full EFC filled only with open files
     * prevents further files from being cached.  Open and hold open 3 files
     * through the EFC, then open the fourth and verify that it was not added to
     * the EFC. */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared != f1->shared)
        TEST_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared != f2->shared)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared != f3->shared)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp4->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp4, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 7: Test multiple file opens.  Open a file twice, close it once, then
     * verify that it is not evicted by H5F__efc_release(). */
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Close parent file */
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    PASSED();

    return 0;

error:
    return 1;
} /* test_single */

/*-------------------------------------------------------------------------
 * Function:    test_graph_nocycle
 *
 * Purpose:     Tests manipulations on a graph of files with external file
 *              caches.  The graph does not contain cycles.
 *
 * Return:      Success: 0
 *              Failure: Number of errors
 *
 *-------------------------------------------------------------------------
 */
static unsigned
test_graph_nocycle(void)
{
    H5F_t *f0    = NULL; /* Parent file containing EFC */
    H5F_t *f1    = NULL; /* Child file */
    H5F_t *f2    = NULL; /* Child file */
    H5F_t *f3    = NULL; /* Child file */
    H5F_t *f4    = NULL; /* Child file */
    H5F_t *ftmp1 = NULL; /* Temp file */
    H5F_t *ftmp2 = NULL; /* Temp file */
    H5F_t *ftmp3 = NULL; /* Temp file */
    H5F_t *ftmp4 = NULL; /* Temp file */

    TESTING("graph of EFCs without cycles");

    /* Set EFC size to 8. Do this instead of H5F__efc_create() so we can pass
     * a file pointer to H5F__efc_open containing the EFC. Set to a high number
     * because we don't test the EFC becoming too large in this test.
     */
    if (H5Pset_elink_file_cache_size(fapl_id, 8) < 0)
        TEST_ERROR;

    /* Test 1: Simple 3 file chain. Open file 1 through file 0, then open file
     * 2 through file 1. Release file 0's EFC and verify that file 2 gets its
     * ref count reduced (implying file 1 was closed). Do the same with the
     * opening order reversed.
     */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) <
        0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, ftmp1->shared->efc, &f2, filename[2],
                      H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 2: 5 file chain.  The parent file has 2 child files, each of which
     * has their own child file.  Verifies that releasing the parent's EFC
     * closes all 4 children. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp4->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 3: Simple "inverted" tree.  Two parent files share a child file,
     * which has its own child file.  Verify that the child's child is not
     * closed until both parents' EFCs are released.  First release through one
     * parent, then reopen through that parent and release the other, then
     * re-release the first parent. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_release(f1->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 4: Simple "diamond" tree.  The parent file has two children, which
     * shared the same child.  Verify that releasing the parent file closes all
     * files. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 3)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 5: Dense 5 file graph.  f0 caches f1, f2, f3 and f4.  f1 and f2
     * each cache f3 and f4.  f3 caches f4.  Verify that releasing f0 closes all
     * files. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp4->shared->nrefs != 5)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    PASSED();

    return 0;

error:
    return 1;
} /* test_graph_nocycle */

/*-------------------------------------------------------------------------
 * Function:    test_graph_cycle
 *
 * Purpose:     Tests manipulations on a graph of files with external file
 *              caches containing cycles.
 *
 * Return:      Success: 0
 *              Failure: Number of errors
 *
 *-------------------------------------------------------------------------
 */
static unsigned
test_graph_cycle(void)
{
    H5F_t *f0    = NULL; /* File */
    H5F_t *f1    = NULL; /* File */
    H5F_t *f2    = NULL; /* File */
    H5F_t *f3    = NULL; /* File */
    H5F_t *f4    = NULL; /* File */
    H5F_t *f5    = NULL; /* File */
    H5F_t *ftmp0 = NULL; /* Temp file */
    H5F_t *ftmp1 = NULL; /* Temp file */
    H5F_t *ftmp2 = NULL; /* Temp file */
    H5F_t *ftmp3 = NULL; /* Temp file */

    TESTING("graph of EFCs with cycles");

    /* Set EFC size to 8. Do this instead of H5F__efc_create() so we can pass
     * a file pointer to H5F__efc_open containing the EFC. Set to a high number
     * because we don't test the EFC becoming too large in this test.
     */
    if (H5Pset_elink_file_cache_size(fapl_id, 8) < 0)
        TEST_ERROR;

    /* Test 1: File caches itself. Verify that closing the file causes it to be
     * actually closed, and there is no other unexpected behavior.
     */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 2: Indirectly referenced file caches itself.  Same as above except
     * the file is part of another file's EFC. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 3: Simple 2 file cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 4: Simple 2 file cycle (indirectly referenced) */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 5: Parallel double cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 6: Parallel double cycle with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 7: Chained parallel double cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 8: Chained parallel double cycle with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 9: Simple 2 file cycle, extra ID on root */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp1, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared != ftmp0->shared)
        TEST_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;
    if (H5F_try_close(ftmp0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 10: Simple 2 file cycle, extra ID on second file */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (ftmp1->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 11: Parallel double cycle, extra ID on a child file */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 12: Parallel double cycle, extra ID on a child file, with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 3)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_release(ftmp2->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp2, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 13: Chained parallel double cycle, extra ID on a child file */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 14: Chained parallel double cycle, extra ID on a child file, with
     * release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(ftmp3->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 15: One local and one remote cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 16: One local and one remote cycle, with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 17: One local and one remote cycle, remote cycle held open */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 18: One local and one remote cycle, remote cycle held open, with
     * release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (ftmp3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_release(ftmp3->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (ftmp3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(ftmp3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 19: "Diamond" shape with links moving from bottom (root) to top.
     * Also cycle between bottom (root) and top and cycles on the sides. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f4->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f4, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f5->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f5, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f5) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f5->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f5, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 20: "Diamond" shape with links moving from bottom (root) to top.
     * Also cycle between bottom (root) and top, cycles on the sides, and
     * release the files instead of closing. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f4->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f4, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f5->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f5, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f5) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f5->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f5, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 21: "Diamond" shape with links moving from bottom (root) to top.
     * Also cycle between bottom (root) and top, cycles on sides held open. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f4->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f4, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f5->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f5, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f5) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f5, filename[5], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f5, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f5->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f5, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 22: "Diamond" shape with links moving from bottom (root) to top.
     * Also cycle between bottom (root) and top, cycles on sides held open.
     * Also release the files instead of closing. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f4, filename[4], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f4->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f4, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, f4) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f4, filename[4], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f5, filename[5], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f5->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f5, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f5) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f5, filename[5], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 2)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 3)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_release(f4->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (f5->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_release(f5->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (f4->shared->nrefs != 1)
        TEST_ERROR;
    if (f5->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f4, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f5, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 23: Dense "ball" of files.  4 files each cache all files (including
     * itself). */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 24: Dense "ball" of files.  4 files each cache all files (including
     * itself).  Release the files instead of closing. */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f2->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_open(false, f3->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp2) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f3->shared->efc, &ftmp3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f3, ftmp3) < 0)
        FAIL_STACK_ERROR;

    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f3) < 0)
        FAIL_STACK_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 25: File held open by EFC client interrupts cycle, with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 26: File held open by EFC does not interrupt cycle, with release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_efc_close(f0, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 27: File held open by EFC client through non-parent file does not
     * interrupt cycle, but parent file does (no valid way around it) */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_efc_close(f2, f1) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 3)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 28: File held open by EFC client through non-parent file does not
     * interrupt cycle, but parent file does (no valid way around it), with
     * release */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f2->shared->efc, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f3, filename[3], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 2)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_release(f0->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F__efc_release(f2->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_efc_close(f1, f3) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f2, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_release(f2->shared->efc) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f3, filename[3], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f3->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f3, NULL) < 0)
        FAIL_STACK_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 29: File without EFC interrupts cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5Pset_elink_file_cache_size(fapl_id, 0) < 0)
        TEST_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5Pset_elink_file_cache_size(fapl_id, 8) < 0)
        TEST_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;

    /* Test 30: File without EFC does not interrupt cycle */
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f0->shared->efc, &f1, filename[1], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &ftmp0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f1, ftmp0) < 0)
        FAIL_STACK_ERROR;
    if (H5F_efc_close(f0, f1) < 0)
        FAIL_STACK_ERROR;
    if (H5Pset_elink_file_cache_size(fapl_id, 0) < 0)
        TEST_ERROR;
    if (H5F__efc_open(false, f1->shared->efc, &f2, filename[2], H5F_ACC_RDWR | H5F_ACC_CREAT | H5F_ACC_TRUNC,
                      fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (H5Pset_elink_file_cache_size(fapl_id, 8) < 0)
        TEST_ERROR;
    if (H5F_efc_close(f1, f2) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 2)
        TEST_ERROR;

    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f0, filename[0], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f0->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f0, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f1, filename[1], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f1->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f1, NULL) < 0)
        FAIL_STACK_ERROR;
    if (H5F_open(false, &f2, filename[2], H5F_ACC_RDWR, fcpl_id, fapl_id) < 0)
        FAIL_STACK_ERROR;
    if (f2->shared->nrefs != 1)
        TEST_ERROR;
    if (H5F_try_close(f2, NULL) < 0)
        FAIL_STACK_ERROR;

    PASSED();

    return 0;

error:
    return 1;
} /* test_graph_cycle */

/*-------------------------------------------------------------------------
 * Function:    main
 *
 * Purpose:     Test the external file cache code
 *
 * Return:      EXIT_SUCCESS/EXIT_FAILURE
 *
 *-------------------------------------------------------------------------
 */
int
main(void)
{
    unsigned              nerrors = 0;            /* track errors */
    H5P_genplist_t       *plist;                  /* Property list pointer for FAPL */
    H5VL_connector_prop_t connector_prop;         /* Property for VOL connector ID & info */
    bool                  api_ctx_pushed = false; /* Whether API context pushed */
    int                   i;                      /* iterator */

    /* Test Setup */
    puts("Testing the external file cache");

    /* Create property lists */
    fcpl_id = H5Pcreate(H5P_FILE_CREATE);
    fapl_id = h5_fileaccess();

    /* Allocate memory for filenames */
    for (i = 0; i < N_FILENAMES; i++) {
        filename[i] = (char *)calloc(PATH_MAX, sizeof(char));
    }

    /* Patch filenames */
    h5_fixname(FILENAME[0], fapl_id, filename[0], PATH_MAX);
    h5_fixname(FILENAME[1], fapl_id, filename[1], PATH_MAX);
    h5_fixname(FILENAME[2], fapl_id, filename[2], PATH_MAX);
    h5_fixname(FILENAME[3], fapl_id, filename[3], PATH_MAX);
    h5_fixname(FILENAME[4], fapl_id, filename[4], PATH_MAX);
    h5_fixname(FILENAME[5], fapl_id, filename[5], PATH_MAX);

    /* Push API context */
    if (H5CX_push() < 0)
        FAIL_STACK_ERROR;
    api_ctx_pushed = true;

    /* Get the VOL info from the fapl */
    plist = (H5P_genplist_t *)H5I_object(fapl_id);
    H5P_peek(plist, H5F_ACS_VOL_CONN_NAME, &connector_prop);

    /* Stash a copy of the "top-level" connector property, before any pass-through
     *  connectors modify or unwrap it.
     */
    H5CX_set_vol_connector_prop(&connector_prop);

    /* Test Functions */
    nerrors += test_single();
    nerrors += test_graph_nocycle();
    nerrors += test_graph_cycle();

    /* Close property lists */
    if (H5Pclose(fcpl_id) < 0)
        TEST_ERROR;

    /* Verify symbol table messages are cached */
    nerrors += (h5_verify_cached_stabs(FILENAME, fapl_id) < 0 ? 1 : 0);

    /* Pop API context */
    if (api_ctx_pushed && H5CX_pop(false) < 0)
        FAIL_STACK_ERROR;
    api_ctx_pushed = false;

    if (nerrors)
        goto error;

    puts("All external file cache tests passed.");

    h5_delete_all_test_files(FILENAME, fapl_id);
    H5Pclose(fapl_id);

    for (i = 0; i < N_FILENAMES; i++) {
        free(filename[i]);
    }

    return EXIT_SUCCESS;

error:
    puts("*** TESTS FAILED ***");

    H5E_BEGIN_TRY
    {
        H5Pclose(fapl_id);
    }
    H5E_END_TRY

    if (api_ctx_pushed)
        H5CX_pop(false);

    for (i = 0; i < N_FILENAMES; i++) {
        free(filename[i]);
    }

    return EXIT_FAILURE;
} /* end main() */
